from distutils.core import setup

setup(
    name='nester',
    version='1.0.0',
    py_modules=['nester'],
    author='Leo',
    author_email='leozhang621@gmail.com',
    description='A test python modules',
    url='http://www.headfirstlab.com',
)
